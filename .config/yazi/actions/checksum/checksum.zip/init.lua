local M = {}

function M.init(_, opts)
	-- Get the selected file or directory
	local target = opts.selected[1]

	-- Check if target is a directory
	local stat_output = Command("test"):arg({ "-d", target }):status()
	local is_directory = stat_output and stat_output.success

	-- Algorithm options for popup menu
	local menuOptions = {
		"MD5",
		"SHA1",
		"SHA256",
		"SHA512",
	}

	-- Map cursor position to algorithm command
	local algo_map = {
		[1] = { cmd = "md5sum", name = "MD5" },
		[2] = { cmd = "sha1sum", name = "SHA1" },
		[3] = { cmd = "sha256sum", name = "SHA256" },
		[4] = { cmd = "sha512sum", name = "SHA512" },
	}

	local selected_algo
	local cancel = false

	-- Confirmation callback
	local onConfirm = function(cursor)
		selected_algo = algo_map[cursor]
	end

	-- Cancel callback
	local onCancel = function()
		cancel = true
	end

	-- Show popup menu
	local menu = Popup.Menu:init(menuOptions, opts.flags.around, onConfirm, onCancel)
	menu:show()

	-- User cancelled
	if cancel or not selected_algo then
		return
	end

	local algo = selected_algo
	local output, err

	if is_directory then
		-- For directories: recursively hash all files, sort, and hash the result
		local cmd = string.format(
			"find %s -type f -exec %s {} + 2>/dev/null | sort | %s",
			ya.quote(target),
			algo.cmd,
			algo.cmd
		)

		output, err = Command("sh")
			:arg({ "-c", cmd })
			:stdout(Command.PIPED)
			:output()
	else
		-- For files: direct checksum
		output, err = Command(algo.cmd)
			:arg(target)
			:stdout(Command.PIPED)
			:output()
	end

	if not output or output.status.code ~= 0 then
		ya.notify({
			title = "Checksum Error",
			content = string.format("Failed to calculate %s checksum", algo.name),
			timeout = 6.0,
			level = "error",
		})
		return
	end

	-- Extract checksum from output (format: "hash  filename")
	local checksum = string.match(output.stdout, "^(%S+)")

	if checksum then
		-- Copy to clipboard
		ya.clipboard(checksum)

		-- Show notification with the checksum
		local target_type = is_directory and "Directory" or "File"
		ya.notify({
			title = string.format("%s %s Checksum", algo.name, target_type),
			content = string.format("%s\n\n(Copied to clipboard)", checksum),
			timeout = 10.0,
			level = "info",
		})
	else
		ya.notify({
			title = "Checksum Error",
			content = "Failed to parse checksum output",
			timeout = 6.0,
			level = "error",
		})
	end
end

return M
