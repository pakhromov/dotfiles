local config = {
	name = "calculate checksum",
	single_or_multi = "single",
}

return config
